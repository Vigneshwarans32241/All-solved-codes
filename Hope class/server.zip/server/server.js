const express = require("express");
const app = express();
const PORT = 4444;
app.get("/",(req,res) =>{
    res.send("hi from server")
});
app.listen(PORT,() =>{
    console.log(`Server is running on http://localhost:${PORT}`);
})